CREATE VIEW `v_no_org` AS
  SELECT
    `njdtjsis`.`gx_sys_org_copy`.`row_id`          AS `row_id`,
    `njdtjsis`.`gx_sys_org_copy`.`org_name`        AS `org_name`,
    `njdtjsis`.`gx_sys_org_copy`.`org_show_name`   AS `org_show_name`,
    `njdtjsis`.`gx_sys_org_copy`.`org_en_name`     AS `org_en_name`,
    `njdtjsis`.`gx_sys_org_copy`.`org_intro`       AS `org_intro`,
    `njdtjsis`.`gx_sys_org_copy`.`create_time`     AS `create_time`,
    `njdtjsis`.`gx_sys_org_copy`.`create_user_id`  AS `create_user_id`,
    `njdtjsis`.`gx_sys_org_copy`.`modify_time`     AS `modify_time`,
    `njdtjsis`.`gx_sys_org_copy`.`modify_user_id`  AS `modify_user_id`,
    `njdtjsis`.`gx_sys_org_copy`.`data_status`     AS `data_status`,
    `njdtjsis`.`gx_sys_org_copy`.`data_order`      AS `data_order`,
    `njdtjsis`.`gx_sys_org_copy`.`parent_org_id`   AS `parent_org_id`,
    `njdtjsis`.`gx_sys_org_copy`.`parent_org_name` AS `parent_org_name`,
    `njdtjsis`.`gx_sys_org_copy`.`org_type`        AS `org_type`,
    `njdtjsis`.`gx_sys_org_copy`.`is_main_page`    AS `is_main_page`,
    `njdtjsis`.`gx_sys_org_copy`.`org_bd_id`       AS `org_bd_id`,
    `njdtjsis`.`gx_sys_org_copy`.`org_bd_name`     AS `org_bd_name`,
    `njdtjsis`.`gx_sys_org_copy`.`org_com_id`      AS `org_com_id`,
    `njdtjsis`.`gx_sys_org_copy`.`is_show`         AS `is_show`
  FROM `njdtjsis`.`gx_sys_org_copy`
  WHERE (NOT (`njdtjsis`.`gx_sys_org_copy`.`row_id` IN (SELECT `njdtjsis`.`gx_sys_att_rule`.`org_row_id`
                                                        FROM `njdtjsis`.`gx_sys_att_rule`)))