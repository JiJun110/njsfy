CREATE VIEW `v_view_column_article` AS
  SELECT
    `r`.`row_id`             AS `v_column_article_key`,
    `a`.`article_title`      AS `article_title`,
    `a`.`article_type`       AS `article_type`,
    `a`.`article_content`    AS `article_content`,
    `a`.`article_status`     AS `article_status`,
    `a`.`create_time`        AS `create_time`,
    `a`.`order_num`          AS `order_num`,
    `a`.`comment`            AS `comment`,
    `a`.`bd_id`              AS `bd_id`,
    `a`.`bd_name`            AS `bd_name`,
    `c`.`column_name`        AS `column_name`,
    `c`.`row_id`             AS `column_id`,
    `a`.`row_id`             AS `article_id`,
    `a`.`is_news_pic`        AS `is_news_pic`,
    `a`.`pic_file_name`      AS `pic_file_name`,
    `a`.`pic_file_real_name` AS `pic_file_real_name`,
    `a`.`voted_num`          AS `voted_num`,
    `a`.`vote_limit_time`    AS `vote_limit_time`,
    `a`.`is_vote`            AS `is_vote`,
    `a`.`vote_method`        AS `vote_method`,
    `a`.`max_vote_num`       AS `max_vote_num`
  FROM ((`njdtjsis`.`gx_view_column` `c`
    JOIN `njdtjsis`.`gx_view_column_article` `a`) JOIN `njdtjsis`.`gx_view_column_article_relation` `r`)
  WHERE ((`c`.`row_id` = `r`.`column_id`) AND (`a`.`row_id` = `r`.`article_id`))