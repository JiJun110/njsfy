CREATE VIEW `v_yqaqdj` AS
  SELECT DISTINCT `njsfy`.`medicine_instance`.`yq_aqdj` AS `yq_aqdj`
  FROM `njsfy`.`medicine_instance`