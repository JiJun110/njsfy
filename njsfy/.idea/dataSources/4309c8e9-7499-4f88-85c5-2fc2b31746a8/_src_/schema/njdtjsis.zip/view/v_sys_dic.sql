CREATE VIEW `v_sys_dic` AS
  SELECT
    concat(`d`.`ROW_ID`, '_', `i`.`ROW_ID`) AS `v_sys_dic_key`,
    `i`.`DIC_FUNCTION_NAME`                 AS `index_dic_name`,
    `i`.`DIC_FUNCTION_ID`                   AS `index_dic_id`,
    `i`.`DIC_FUNCTION_DEC`                  AS `index_dic_desc`,
    `d`.`DIC_NAME`                          AS `record_dic_name`,
    `d`.`DIC_ID`                            AS `record_dic_id`,
    `d`.`DIC_SHOW_VAL`                      AS `DIC_SHOW_VAL`,
    `d`.`DIC_VALUE`                         AS `DIC_VALUE`,
    `d`.`DIC_TYPE`                          AS `DIC_TYPE`,
    `d`.`ORDER_NUM`                         AS `ORDER_NUM`,
    `d`.`max_status`                        AS `max_status`,
    `d`.`max_id`                            AS `max_id`
  FROM (`njdtjsis`.`gx_sys_dic_index` `i`
    JOIN `njdtjsis`.`gx_sys_dic_record` `d`)
  WHERE (`i`.`ROW_ID` = `d`.`TABLE_ID`)