CREATE VIEW `v_dt_yc` AS
  SELECT
    `m`.`row_id`            AS `business_id`,
    `m`.`applicant_name`    AS `applicant_name`,
    `m`.`applicant_phone`   AS `applicant_phone`,
    `m`.`applicant_id_card` AS `applicant_id_card`,
    `m`.`start_time`        AS `start_time`,
    `m`.`create_user_id`    AS `create_user_id`,
    `m`.`create_user_name`  AS `create_user_name`,
    `m`.`create_time`       AS `create_time`,
    `pi`.`process_id`       AS `process_id`,
    `pi`.`row_id`           AS `instance_id`,
    `pi`.`instance_state`   AS `instance_state`,
    `ai`.`row_id`           AS `row_id`,
    `ai`.`act_id`           AS `act_id`,
    `ai`.`act_name`         AS `act_name`,
    `ai`.`handle_user`      AS `handle_user`,
    `ai`.`handle_user1`     AS `handle_user1`,
    `ai`.`act_back`         AS `act_back`,
    `ai`.`act_next`         AS `act_next`,
    `ai`.`active_state`     AS `active_state`,
    `ai`.`active_time`      AS `active_time`,
    `ai`.`finish_time`      AS `finish_time`,
    `ai`.`step_state`       AS `step_state`
  FROM `njdtjsis`.`dt_yc_apply` `m`
    JOIN `njdtjsis`.`proc_instance` `pi`
    JOIN `njdtjsis`.`proc_act_instance` `ai`
  WHERE ((`m`.`row_id` = `pi`.`business_id`) AND (`pi`.`row_id` = `ai`.`instance_id`))