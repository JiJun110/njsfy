CREATE VIEW `v_all_phb` AS
  SELECT
    `szgmkxj`.`user_score`.`nick_name`       AS `nick_name`,
    `szgmkxj`.`user_score`.`avatar_url`      AS `avatar_url`,
    sum(`szgmkxj`.`user_score`.`user_score`) AS `score`,
    `szgmkxj`.`user_score`.`user_dtcs`       AS `user_dtcs`,
    `szgmkxj`.`user_score`.`open_id`         AS `open_id`
  FROM `szgmkxj`.`user_score`
  WHERE (`szgmkxj`.`user_score`.`ext1` IS NULL)
  GROUP BY `szgmkxj`.`user_score`.`open_id`
  ORDER BY `score` DESC