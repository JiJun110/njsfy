CREATE VIEW `v_medicine_relation` AS
  SELECT
    `njsfy`.`medicine_type`.`medicine_type_id`          AS `medicine_type_id`,
    `njsfy`.`medicine_type`.`medicine_type_name`        AS `medicine_type_name`,
    `njsfy`.`medicine_type`.`medicine_parent_type_id`   AS `medicine_parent_type_id`,
    `njsfy`.`medicine_type`.`medicine_parent_type_name` AS `medicine_parent_type_name`,
    `njsfy`.`medicine_instance`.`medicine_name`         AS `medicine_name`
  FROM (`njsfy`.`medicine_type`
    JOIN `njsfy`.`medicine_instance`
      ON ((`njsfy`.`medicine_type`.`row_id` = `njsfy`.`medicine_instance`.`medicine_type`)))