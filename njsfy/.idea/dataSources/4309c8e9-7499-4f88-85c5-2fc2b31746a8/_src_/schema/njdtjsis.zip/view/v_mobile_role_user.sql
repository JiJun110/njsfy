CREATE VIEW `v_mobile_role_user` AS
  SELECT
    concat(`r`.`row_id`, '_', `u`.`user_id`) AS `v_mobile_role_user_key`,
    `u`.`row_id`                             AS `user_key`,
    `u`.`user_name`                          AS `user_name`,
    `u`.`user_show_name`                     AS `user_show_name`,
    `u`.`user_en_name`                       AS `user_en_name`,
    `u`.`user_id`                            AS `user_id`,
    `u`.`data_status`                        AS `data_status`,
    `u`.`data_order`                         AS `data_order`,
    `u`.`user_sex`                           AS `user_sex`,
    `u`.`user_type`                          AS `user_type`,
    `r`.`row_id`                             AS `role_key`,
    `r`.`role_name`                          AS `role_name`,
    `r`.`role_id`                            AS `role_id`,
    `r`.`role_intro`                         AS `role_intro`,
    `r`.`data_order`                         AS `r_data_order`
  FROM ((`njdtjsis`.`gx_oa_mobile_role` `r`
    JOIN `njdtjsis`.`gx_sys_user` `u`) JOIN `njdtjsis`.`gx_oa_mobile_role_has_user` `ru`)
  WHERE ((`r`.`row_id` = `ru`.`role_id`) AND (`u`.`user_id` = `ru`.`user_id`))