CREATE VIEW `v_user` AS
  SELECT
    concat(`o`.`row_id`, `u`.`user_id`) AS `v_user_key`,
    `o`.`org_name`                      AS `org_name`,
    `o`.`parent_org_id`                 AS `p_org_id`,
    `o`.`parent_org_name`               AS `p_org_name`,
    `o`.`org_type`                      AS `org_type`,
    `o`.`row_id`                        AS `org_id`,
    `u`.`user_name`                     AS `user_name`,
    `u`.`user_en_name`                  AS `user_password`,
    `u`.`user_id`                       AS `user_id`,
    `u`.`user_type`                     AS `user_type`,
    `u`.`user_mobile_num`               AS `user_mobile_num`,
    `u`.`data_status`                   AS `user_status`,
    `u`.`sys_color_id`                  AS `sys_color_id`,
    `u`.`user_card_id`                  AS `user_card_id`,
    `o`.`org_com_id`                    AS `com_org_id`,
    `o`.`org_bd_id`                     AS `com_bd_id`,
    `uio`.`data_order`                  AS `data_order`,
    `uio`.`row_id`                      AS `uio_row_id`,
    `u`.`row_id`                        AS `user_row_id`,
    `u`.`client_id`                     AS `client_id`
  FROM ((`njsfy`.`gx_sys_org` `o`
    JOIN `njsfy`.`gx_sys_user` `u`) JOIN `njsfy`.`gx_sys_user_in_org` `uio`)
  WHERE ((`o`.`row_id` = `uio`.`org_id`) AND (`u`.`user_id` = `uio`.`user_id`))
  ORDER BY `uio`.`data_order`