CREATE VIEW `v_user_in_org_att` AS
  SELECT
    `re`.`rowId`           AS `attRowId`,
    `re`.`signTime`        AS `signTime`,
    `re`.`userId`          AS `userId`,
    `re`.`userName`        AS `userName`,
    `vu`.`org_name`        AS `orgName`,
    `vu`.`org_id`          AS `orgId`,
    `vu`.`com_bd_id`       AS `bdId`,
    `re`.`ruleName`        AS `ruleName`,
    `re`.`earlyTime`       AS `earlyTime`,
    `re`.`lastTime`        AS `lastTime`,
    `re`.`count`           AS `count`,
    `re`.`workTime`        AS `workTime`,
    `re`.`resultKey`       AS `resultKey`,
    `re`.`resultType`      AS `resultType`,
    `re`.`resultCheckType` AS `resultCheckType`,
    `re`.`signType`        AS `signType`,
    `re`.`doorControlName` AS `doorControlName`,
    `vu`.`data_order`      AS `dataOrder`,
    `vu`.`user_type`       AS `userType`
  FROM (`njdtjsis`.`gx_sys_attendance_result` `re`
    JOIN `njdtjsis`.`v_user_copy` `vu`)
  WHERE (`re`.`userId` = convert(`vu`.`user_id` USING utf8mb4))