CREATE VIEW `v_att_all` AS
  SELECT
    concat(`a`.`uniqueId`, '_', convert(`u`.`user_id` USING utf8mb4)) AS `v_att_user_key`,
    `a`.`uniqueId`                                                    AS `uniqueId`,
    `a`.`signTime`                                                    AS `signTime`,
    `a`.`doorControlName`                                             AS `doorControlName`,
    `a`.`certificateNo`                                               AS `certificateNo`,
    `a`.`projectId`                                                   AS `projectId`,
    `a`.`imageUrl`                                                    AS `imageUrl`,
    `a`.`signType`                                                    AS `signType`,
    `u`.`row_id`                                                      AS `user_key`,
    `u`.`user_id`                                                     AS `user_id`,
    `u`.`user_name`                                                   AS `user_name`,
    `u`.`user_type`                                                   AS `user_type`,
    `o`.`row_id`                                                      AS `org_id`,
    `o`.`org_name`                                                    AS `org_name`
  FROM (((`njdtjsis`.`gx_sys_attendance_all` `a`
    JOIN `njdtjsis`.`gx_sys_user` `u`) JOIN `njdtjsis`.`gx_sys_user_in_org_copy` `or`) JOIN
    `njdtjsis`.`gx_sys_org_copy` `o`)
  WHERE ((`a`.`certificateNo` = convert(`u`.`user_card_id` USING utf8mb4)) AND (`u`.`user_id` = `or`.`user_id`) AND
         (`or`.`org_id` = `o`.`row_id`))