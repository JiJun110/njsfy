CREATE VIEW `v_tk_xuanxiang` AS
  SELECT DISTINCT
    `szgmkxj`.`question_bank`.`question`        AS `question`,
    `szgmkxj`.`question_bank`.`daan`            AS `daan`,
    `szgmkxj`.`xuanxiang_bank`.`xuanxiang_name` AS `xuanxiang_name`
  FROM `szgmkxj`.`question_bank`
    JOIN `szgmkxj`.`xuanxiang_bank`
  WHERE (`szgmkxj`.`question_bank`.`question_type` = `szgmkxj`.`xuanxiang_bank`.`xuanxiang_type`)