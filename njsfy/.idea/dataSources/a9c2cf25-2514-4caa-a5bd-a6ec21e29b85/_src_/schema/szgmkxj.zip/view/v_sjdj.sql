CREATE VIEW `v_sjdj` AS
  SELECT
    `szgmkxj`.`user_score`.`nick_name`        AS `nick_name`,
    `szgmkxj`.`user_score`.`user_score`       AS `user_score`,
    `szgmkxj`.`gx_sys_user`.`user_name`       AS `user_name`,
    min(`szgmkxj`.`user_score`.`create_time`) AS `create_time`,
    `szgmkxj`.`user_score`.`open_id`          AS `open_id`
  FROM (`szgmkxj`.`user_score`
    JOIN `szgmkxj`.`gx_sys_user`
      ON ((`szgmkxj`.`user_score`.`open_id` = convert(`szgmkxj`.`gx_sys_user`.`openid` USING utf8mb4))))
  WHERE ((`szgmkxj`.`user_score`.`user_score` >= 20) AND (`szgmkxj`.`user_score`.`create_time` IS NOT NULL))
  GROUP BY `szgmkxj`.`user_score`.`open_id`