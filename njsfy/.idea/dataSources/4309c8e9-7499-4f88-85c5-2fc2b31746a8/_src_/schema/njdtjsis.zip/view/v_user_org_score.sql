CREATE VIEW `v_user_org_score` AS
  SELECT
    concat(`s`.`row_id`, '_', convert(`u`.`user_id` USING utf8mb4)) AS `v_score_user_key`,
    `s`.`row_id`                                                    AS `score_key`,
    `s`.`record_score`                                              AS `record_score`,
    `s`.`record_type`                                               AS `record_type`,
    `s`.`record_time`                                               AS `record_time`,
    `u`.`row_id`                                                    AS `user_key`,
    `u`.`user_id`                                                   AS `user_id`,
    `u`.`user_name`                                                 AS `user_name`,
    `o`.`row_id`                                                    AS `org_id`,
    `o`.`org_name`                                                  AS `org_name`,
    `o`.`parent_org_id`                                             AS `parent_org_id`,
    `o`.`parent_org_name`                                           AS `parent_org_name`,
    `s`.`order_num`                                                 AS `data_order`
  FROM (((`njdtjsis`.`gx_sys_score_record` `s`
    JOIN `njdtjsis`.`gx_sys_user` `u`) JOIN `njdtjsis`.`gx_sys_user_in_org` `io`) JOIN `njdtjsis`.`gx_sys_org` `o`)
  WHERE ((`s`.`user_id` = convert(`u`.`user_id` USING utf8mb4)) AND (`u`.`user_id` = `io`.`user_id`) AND
         (`io`.`org_id` = `o`.`row_id`))