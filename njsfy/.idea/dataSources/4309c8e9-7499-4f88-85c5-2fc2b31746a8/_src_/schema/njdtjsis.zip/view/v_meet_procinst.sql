CREATE VIEW `v_meet_procinst` AS
  SELECT
    `m`.`row_id`            AS `row_id`,
    `m`.`applicant_name`    AS `applicant_name`,
    `m`.`applicant_phone`   AS `applicant_phone`,
    `m`.`applicant_id_card` AS `applicant_id_card`,
    `m`.`company_name`      AS `company_name`,
    `m`.`start_time`        AS `meet_start_time`,
    `m`.`end_time`          AS `meet_end_time`,
    `m`.`selected_room`     AS `selected_room`,
    `m`.`create_user_id`    AS `create_user_id`,
    `m`.`create_user_name`  AS `create_user_name`,
    `m`.`create_time`       AS `create_time`,
    `pi`.`process_id`       AS `process_id`,
    `pi`.`row_id`           AS `instance_id`,
    `pi`.`instance_state`   AS `instance_state`,
    `pi`.`active_state`     AS `active_state`,
    `pi`.`active_user_name` AS `active_user_name`,
    `pi`.`create_time`      AS `start_time`,
    `pi`.`end_time`         AS `end_time`
  FROM `njdtjsis`.`meeting_room_lease_apply` `m`
    JOIN `njdtjsis`.`proc_instance` `pi`
  WHERE (`m`.`row_id` = `pi`.`business_id`)