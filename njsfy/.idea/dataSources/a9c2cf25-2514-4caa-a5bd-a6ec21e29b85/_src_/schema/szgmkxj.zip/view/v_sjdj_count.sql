CREATE VIEW `v_sjdj_count` AS
  SELECT
    `szgmkxj`.`user_score`.`nick_name`                                                                            AS `nick_name`,
    sum(
        `szgmkxj`.`user_score`.`user_dtcs`)                                                                       AS `user_dtcs`,
    `v_sjdj`.`user_name`                                                                                          AS `user_name`,
    ((unix_timestamp(`v_sjdj`.`create_time`) - unix_timestamp(min(`szgmkxj`.`user_score`.`create_time`))) /
     3600)                                                                                                        AS `create_time`,
    `szgmkxj`.`user_score`.`open_id`                                                                              AS `open_id`
  FROM (`szgmkxj`.`user_score`
    JOIN `szgmkxj`.`v_sjdj` ON ((`v_sjdj`.`open_id` = `szgmkxj`.`user_score`.`open_id`)))
  WHERE (`szgmkxj`.`user_score`.`create_time` <= `v_sjdj`.`create_time`)
  GROUP BY `szgmkxj`.`user_score`.`open_id`