CREATE VIEW `v_changshang` AS
  SELECT DISTINCT
    `njsfy`.`medicine_instance`.`chang_shang` AS `chang_shang`,
    `njsfy`.`medicine_instance`.`row_id`      AS `row_id`
  FROM `njsfy`.`medicine_instance`