CREATE VIEW `v_phb` AS
  SELECT
    `szgmkxj`.`user_score`.`nick_name`       AS `nick_name`,
    `szgmkxj`.`user_score`.`avatar_url`      AS `avatar_url`,
    max(`szgmkxj`.`user_score`.`user_score`) AS `score`,
    `szgmkxj`.`user_score`.`user_dtcs`       AS `user_dtcs`,
    `szgmkxj`.`user_score`.`open_id`         AS `open_id`
  FROM `szgmkxj`.`user_score`
  WHERE (`szgmkxj`.`user_score`.`user_dtcs` <> 0)
  GROUP BY `szgmkxj`.`user_score`.`open_id`
  ORDER BY `score` DESC