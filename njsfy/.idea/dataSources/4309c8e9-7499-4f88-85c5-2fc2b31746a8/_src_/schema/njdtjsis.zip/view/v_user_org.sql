CREATE VIEW `v_user_org` AS
  SELECT
    concat(`njdtjsis`.`gx_sys_org`.`row_id`, `njdtjsis`.`gx_hr_user`.`user_id`) AS `user_org_key`,
    `njdtjsis`.`gx_sys_org`.`row_id`                                            AS `row_id`,
    `njdtjsis`.`gx_sys_org`.`org_name`                                          AS `org_name`,
    `njdtjsis`.`gx_hr_user`.`user_name`                                         AS `user_name`,
    `njdtjsis`.`gx_hr_user_in_org`.`user_id`                                    AS `user_id`,
    `njdtjsis`.`gx_hr_user`.`row_id`                                            AS `user_row_id`,
    `njdtjsis`.`gx_hr_user_in_org`.`row_id`                                     AS `between_id`,
    `njdtjsis`.`gx_hr_user_in_org`.`data_order`                                 AS `data_order`,
    `njdtjsis`.`gx_hr_user`.`user_job`                                          AS `user_job`,
    `njdtjsis`.`gx_hr_user`.`user_card_id`                                      AS `user_card_id`
  FROM ((`njdtjsis`.`gx_sys_org`
    JOIN `njdtjsis`.`gx_hr_user`) JOIN `njdtjsis`.`gx_hr_user_in_org`)
  WHERE ((`njdtjsis`.`gx_sys_org`.`row_id` = `njdtjsis`.`gx_hr_user_in_org`.`org_id`) AND
         (`njdtjsis`.`gx_hr_user`.`user_id` = `njdtjsis`.`gx_hr_user_in_org`.`user_id`))