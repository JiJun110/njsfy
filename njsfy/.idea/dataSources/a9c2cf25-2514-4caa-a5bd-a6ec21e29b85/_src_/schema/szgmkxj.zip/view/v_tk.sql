CREATE VIEW `v_tk` AS
  SELECT
    `szgmkxj`.`xuanxiang_bank`.`xuanxiang_name`             AS `xuanxiang_name`,
    `szgmkxj`.`xuanxiang_bank`.`xuanxiang_type`             AS `xuanxiang_type`,
    `szgmkxj`.`xuanxiang_bank`.`xuanxiang_parent_type_name` AS `xuanxiang_parent_type_name`,
    `szgmkxj`.`xuanxiang_bank`.`xuanxiang_parent_type`      AS `xuanxiang_parent_type`,
    `szgmkxj`.`img_record`.`relation_id`                    AS `relation_id`,
    `szgmkxj`.`img_record`.`file_path`                      AS `file_path`,
    `szgmkxj`.`img_record`.`file_name`                      AS `file_name`
  FROM (`szgmkxj`.`xuanxiang_bank`
    JOIN `szgmkxj`.`img_record`)
  WHERE ((`szgmkxj`.`xuanxiang_bank`.`row_id` = `szgmkxj`.`img_record`.`relation_id`) AND
         ((`szgmkxj`.`xuanxiang_bank`.`ext3` IS NULL) OR (`szgmkxj`.`xuanxiang_bank`.`ext3` = '是')))